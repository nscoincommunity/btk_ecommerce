<?php
// Text
$_['text_information']  = 'Informasi';
$_['text_service']      = 'Layanan pelanggan';
$_['text_extra']        = 'Ekstra';
$_['text_contact']      = 'Hubungi kami';
$_['text_return']       = 'Retur / Pengembalian';
$_['text_sitemap']      = 'Peta Situs';
$_['text_manufacturer'] = 'Merek';
$_['text_voucher']      = 'Voucher Hadiah';
$_['text_affiliate']    = 'Afiliasi';
$_['text_special']      = 'Spesial';
$_['text_account']      = 'Akun Saya';
$_['text_order']        = 'Riwayat Pemesanan';
$_['text_wishlist']     = 'Daftar keinginan';
$_['text_newsletter']   = 'Newsletter';
$_['text_powered']      = 'Powered By <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';

$_['text_special']      = 'Produk Diskon';
            