<?php
/**
 * @version		$Id: NAME.xxx 2014-10-9 17:57Z mic $
 * @package		Translation Project
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_footer'] 	= '<a href="http://www.opencart.com" target="_blank"> OpenCart</a> &copy; 2009-2014. Semua Hak Dilindungi Undang-Undang.';
$_['text_version'] 	= 'Versi %s';

$_['text_footer']  = '<span title="Supported By HP Web Design" data-original-title="Supported By HP Web Design" data-toggle="tooltip">Copyright &copy; %s '.date("Y").'</span';
            